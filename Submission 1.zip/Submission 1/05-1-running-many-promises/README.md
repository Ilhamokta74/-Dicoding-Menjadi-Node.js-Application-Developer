# 05-1-running-many-promises
> **Tugas**: Di dalam folder `05-1-running-many-promises`, terdapat berkas `app.js`.
Bukalah berkas tersebut dan kerjakan @TODO yang ada di dalamnya.

**Catatan**
- Jangan ubah atau hapus kode yang berada di dalam berkas `utils.js`.
- Di dalam `app.js`, Anda bisa hindari pengubahan kode di luar dari konteks fungsi `getUserData`.
- Anda bisa menyelesaikan tugas ini dengan menggunakan `async-await` atau fungsi promise seperti `Promise.all`, dan sebagainya.
- **Soal ini hanya dapat menggunakan CommonJS**.
