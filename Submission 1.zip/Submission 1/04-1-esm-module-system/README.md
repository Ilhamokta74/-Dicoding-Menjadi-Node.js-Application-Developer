# Instruksi: 04-1-esm-module-system
> **Tugas**: Lengkapi kode yang ditandai dengan komentar `@TODO` pada berkas `main.js`, `utils.js`, dan `UniqueArray.js`. **Dalam kuis ini, Anda hanya bisa memanfaatkan ESM untuk sistem modularisasinya**.

**Catatan:**
- Jangan hapus berkas apa pun yang ada di dalam folder ini.
- Pengubahan kode lain dapat menyebabkan pengujian gagal.
