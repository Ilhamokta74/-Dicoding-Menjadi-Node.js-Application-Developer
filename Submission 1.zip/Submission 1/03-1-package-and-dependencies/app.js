console.log('Hello, world!');
