# 07-1-handling-error
> **Pengantar**: 
Di berkas `app.js` terdapat fungsi bernama `parsedUrl`.
Fungsi tersebut bertujuan untuk mengubah string URL menjadi objek `URL`.
Namun, fungsi tersebut akan membangkitkan error jika argumen yang diberikan bukan merupakan URL.

**Tugas Anda adalah tangani error tersebut agar**:
1. Jika argumen yang diberikan bukan URL, kembalikan dengan nilai `null`.
2. Jika argumen yang diberikan merupakan URL, kembalikan dengan nilai objek URL.
