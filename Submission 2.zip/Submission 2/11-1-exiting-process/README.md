# 11-1-exiting-process
> **Tugas**: Bukalah berkas `app.js` dan simak instruksi yang diberikan pada berkas tersebut.

**Catatan:**
- Jangan hapus berkas apa pun yang sudah ada di folder ini.
- Anda **tidak bisa** menggunakan package pihak ketiga dalam mengerjakan tugas ini.

