/**
 * @TODO
 * 1. Cetak jenis platform pada Terminal
 * 2. Hentikan proses dengan status code non-zero (selain 0)
 */

// Tulis jawaban di bawah ini
// Step 1: Print the platform type to the terminal
console.log(process.platform);

// Step 2: Exit the process with a non-zero status code
process.exit(1);